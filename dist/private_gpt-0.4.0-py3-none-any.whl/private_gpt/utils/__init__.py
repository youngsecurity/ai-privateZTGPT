"""general utils."""
