"""Deprecated Openai compatibility endpoint."""
