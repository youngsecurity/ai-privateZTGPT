"""OpenAI compatibility utilities."""
