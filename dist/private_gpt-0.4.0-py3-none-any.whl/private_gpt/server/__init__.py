"""private-gpt server."""
