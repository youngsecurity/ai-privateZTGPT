"""OpenAI API extensions."""
